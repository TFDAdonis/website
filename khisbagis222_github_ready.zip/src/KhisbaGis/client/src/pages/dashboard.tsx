import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Logo } from "@/components/logo";
import { UsageTracker } from "@/components/usage-tracker";
import { IframeClickOverlay } from "@/components/iframe-click-overlay";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, LogOut, Globe, Wifi, RefreshCw, Building2, Maximize, Minimize } from "lucide-react";
import khisbaLogoPath from "@assets/Screenshot 2025-08-13 140307_1755091817307.png";
import universityLogoPath from "@assets/Screenshot 2025-08-13 140307_1755092670884.png";

interface AuthResponse {
  admin: {
    id: string;
    username: string;
    remainingClicks: number;
    hasSubscription: boolean;
    subscriptionExpiresAt: string | null;
  };
  session: {
    id: string;
    expiresAt: string;
  };
}

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isFrameLoading, setIsFrameLoading] = useState(true);
  const [frameError, setFrameError] = useState(false);
  const [canUseGIS, setCanUseGIS] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // Check authentication status
  const { data: authData, isLoading, error } = useQuery<AuthResponse>({
    queryKey: ["/api/auth/me"],
    retry: false,
  });

  // Logout mutation
  const logoutMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/auth/logout");
      return response.json();
    },
    onSuccess: () => {
      queryClient.clear();
      toast({
        title: "Logged Out",
        description: "You have been successfully logged out",
      });
      setLocation("/");
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Logout Error",
        description: "There was an error logging out",
      });
    }
  });

  // Redirect to login if not authenticated
  useEffect(() => {
    if (error || (!isLoading && !authData)) {
      setLocation("/");
    }
  }, [error, isLoading, authData, setLocation]);

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const handleFrameLoad = () => {
    setIsFrameLoading(false);
    setFrameError(false);
  };

  const handleFrameError = () => {
    setIsFrameLoading(false);
    setFrameError(true);
  };

  const retryFrame = () => {
    setIsFrameLoading(true);
    setFrameError(false);
    // Force iframe reload by updating its src
    const iframe = document.getElementById('gis-frame') as HTMLIFrameElement;
    if (iframe) {
      const src = iframe.src;
      iframe.src = '';
      setTimeout(() => {
        iframe.src = src;
      }, 100);
    }
  };

  const handleUsageUpdate = () => {
    // Check if user can still use GIS
    if (authData) {
      const hasActiveSubscription = authData.admin.hasSubscription && 
        authData.admin.subscriptionExpiresAt && 
        new Date(authData.admin.subscriptionExpiresAt) > new Date();
      
      setCanUseGIS(hasActiveSubscription || authData.admin.remainingClicks > 0);
    }
  };

  // Update usage status when auth data changes
  useEffect(() => {
    handleUsageUpdate();
  }, [authData]);

  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-khisba-dark flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin text-khisba-green mx-auto mb-4" />
          <p className="text-khisba-green font-medium">Verifying authentication...</p>
        </div>
      </div>
    );
  }

  if (!authData) {
    return null; // Will redirect via useEffect
  }

  return (
    <div className="min-h-screen bg-khisba-dark text-white">
      {/* Header */}
      <header className="bg-khisba-gray border-b border-khisba-green/20 p-4" data-testid="header-dashboard">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img 
              src={khisbaLogoPath} 
              alt="Khisba Logo" 
              className="w-12 h-12 object-contain"
              data-testid="img-khisba-logo"
            />
            <Logo size="sm" />
          </div>
          
          <div className="flex items-center space-x-4">
            <Badge variant="secondary" className="bg-khisba-green/10 text-khisba-green border-khisba-green/20">
              <Globe className="w-3 h-3 mr-1" />
              Admin Session
            </Badge>
            
            <span className="text-sm text-gray-400" data-testid="text-username">
              {authData.admin.username}
            </span>
            
            <Button 
              onClick={handleLogout}
              disabled={logoutMutation.isPending}
              variant="destructive"
              size="sm"
              data-testid="button-logout"
            >
              {logoutMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Logging out...
                </>
              ) : (
                <>
                  <LogOut className="mr-2 h-4 w-4" />
                  Logout
                </>
              )}
            </Button>
          </div>
        </div>
      </header>

      {/* Professional Controls Panel */}
      <div className="bg-gradient-to-r from-khisba-gray to-gray-900 border-b-2 border-khisba-green/30 p-4 shadow-lg">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-6">
            <UsageTracker 
              admin={authData.admin} 
              onUsageUpdate={handleUsageUpdate}
            />
            
            <Button
              onClick={retryFrame}
              size="default"
              className="bg-khisba-green hover:bg-khisba-bright text-black font-semibold shadow-lg transition-all duration-200 hover:scale-105"
              data-testid="button-refresh"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Actualiser
            </Button>
          </div>
          
          <div className="flex items-center gap-6">
            <Button
              onClick={toggleFullscreen}
              size="default"
              className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600 text-white font-semibold shadow-lg transition-all duration-200 hover:scale-105"
              data-testid="button-fullscreen"
            >
              {isFullscreen ? (
                <>
                  <Minimize className="w-4 h-4 mr-2" />
                  Exit Fullscreen
                </>
              ) : (
                <>
                  <Maximize className="w-4 h-4 mr-2" />
                  Fullscreen View
                </>
              )}
            </Button>
            
            {/* Professional Connection Status */}
            <div className="flex items-center space-x-3 px-4 py-2 bg-gray-800/80 rounded-lg border border-khisba-green/30 shadow-lg">
              <Wifi className="w-5 h-5 text-khisba-green" />
              <div className="flex flex-col">
                <span className="text-sm font-medium text-white" data-testid="status-connection">
                  {frameError ? 'Disconnected' : 'Connected'}
                </span>
                <span className="text-xs text-gray-400">
                  {frameError ? 'Check connection' : 'Earth Engine Active'}
                </span>
              </div>
              <div className={`w-3 h-3 rounded-full ${frameError ? 'bg-red-500 animate-pulse' : 'bg-khisba-green shadow-lg shadow-khisba-green/50'}`} />
            </div>
          </div>
        </div>
      </div>

      {/* GIS Application Container */}
      <main className={`relative ${isFullscreen ? 'h-screen fixed inset-0 z-50 bg-khisba-dark' : 'h-[calc(100vh-240px)]'}`}>
        {/* Loading Overlay */}
        {isFrameLoading && (
          <div className="absolute inset-0 bg-khisba-dark/90 flex items-center justify-center z-10">
            <div className="text-center">
              <div className="w-16 h-16 border-4 border-khisba-green border-t-transparent rounded-full animate-spin mx-auto mb-4" />
              <p className="text-khisba-green font-medium">Loading GIS Application...</p>
              <p className="text-gray-400 text-sm mt-2">Please wait while the Earth Engine application loads</p>
            </div>
          </div>
        )}

        {/* Error Overlay */}
        {frameError && (
          <div className="absolute inset-0 bg-khisba-dark/90 flex items-center justify-center z-10">
            <div className="text-center max-w-md mx-4">
              <div className="text-red-400 mb-4">
                <svg className="w-16 h-16 mx-auto" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                </svg>
              </div>
              <p className="text-red-400 font-medium mb-2">Failed to load GIS Application</p>
              <p className="text-gray-400 text-sm mb-4">
                The Google Earth Engine application could not be loaded. This may be due to network issues or the service being temporarily unavailable.
              </p>
              <Button 
                onClick={retryFrame}
                className="bg-khisba-green hover:bg-khisba-bright text-black"
                data-testid="button-retry"
              >
                Retry Loading
              </Button>
            </div>
          </div>
        )}

        {/* Usage Blocked Overlay */}
        {!canUseGIS && (
          <div className="absolute inset-0 bg-khisba-dark/95 flex items-center justify-center z-20">
            <div className="text-center max-w-md mx-4">
              <div className="text-khisba-green mb-4">
                <svg className="w-16 h-16 mx-auto" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                </svg>
              </div>
              <p className="text-khisba-green font-medium mb-2">GIS Access Restricted</p>
              <p className="text-gray-400 text-sm mb-4">
                You have used all your free clicks. Subscribe to Barrdi Mob to get unlimited access to the GIS system.
              </p>
            </div>
          </div>
        )}

        {/* Fullscreen Controls */}
        {isFullscreen && (
          <div className="absolute top-4 right-4 z-10 flex items-center gap-2">
            <Button
              onClick={toggleFullscreen}
              size="sm"
              className="bg-khisba-gray/90 hover:bg-khisba-green text-khisba-green hover:text-black border border-khisba-green/20"
              data-testid="button-exit-fullscreen"
            >
              <Minimize className="w-4 h-4 mr-2" />
              Exit Fullscreen
            </Button>
          </div>
        )}

        {/* Professional GIS Iframe Container */}
        <div className="w-full h-full relative bg-gray-900 rounded-lg overflow-hidden border-2 border-khisba-green/20 shadow-2xl">
          {/* Manual Click Test Button */}
          {!authData.admin.hasSubscription && authData.admin.remainingClicks > 0 && (
            <div className="absolute top-4 left-4 z-20">
              <Button
                onClick={() => {
                  if (authData.admin.remainingClicks > 0) {
                    // This simulates an iframe click for testing
                    document.dispatchEvent(new CustomEvent('iframe-click'));
                  }
                }}
                size="sm"
                className="bg-red-600 hover:bg-red-700 text-white shadow-lg"
                data-testid="button-test-click"
              >
                Test Click (-1)
              </Button>
            </div>
          )}
          
          <iframe 
            id="gis-frame"
            src="https://taibifarouk.users.earthengine.app/view/udl22"
            className="w-full h-full border-0 rounded-lg"
            title="Khisba GIS Application - Google Earth Engine"
            allow="geolocation; camera; microphone"
            sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-popups-to-escape-sandbox"
            onLoad={handleFrameLoad}
            onError={handleFrameError}
            data-testid="iframe-gis"
            style={{ 
              pointerEvents: canUseGIS ? 'auto' : 'none',
              filter: canUseGIS ? 'none' : 'grayscale(100%) opacity(50%)'
            }}
          />
          
          {/* Professional loading indicator */}
          {isFrameLoading && (
            <div className="absolute inset-0 bg-gradient-to-br from-khisba-dark via-gray-900 to-black flex items-center justify-center z-10">
              <div className="text-center">
                <div className="w-20 h-20 border-4 border-khisba-green/20 border-t-khisba-green rounded-full animate-spin mx-auto mb-6" />
                <h3 className="text-xl font-semibold text-khisba-green mb-2">Loading Earth Engine</h3>
                <p className="text-gray-400">Initializing GIS platform...</p>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Footer with University Branding - Hidden in fullscreen */}
      {!isFullscreen && (
        <footer className="bg-khisba-gray border-t border-khisba-green/20 p-4">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <div className="flex items-center gap-6">
              <img 
                src={universityLogoPath} 
                alt="University Logo" 
                className="w-16 h-16 object-contain"
                data-testid="img-university-logo"
              />
              <div className="text-left">
                <h3 className="text-khisba-green font-semibold text-lg">Incubator University</h3>
                <p className="text-gray-400 text-sm">Djilali Liabes</p>
                <p className="text-gray-500 text-xs">Sidi Bel Abbes</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="border-khisba-green/20 text-khisba-green">
                <Building2 className="w-3 h-3 mr-1" />
                Academic Partnership
              </Badge>
              <div className="text-right">
                <p className="text-xs text-gray-400">Powered by</p>
                <p className="text-sm text-khisba-green font-medium">Khisba GIS Platform</p>
              </div>
            </div>
          </div>
        </footer>
      )}
    </div>
  );
}
