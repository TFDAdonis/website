import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { SubscriptionModal } from "./subscription-modal";
import { MousePointer, Crown, Clock, Loader2 } from "lucide-react";

interface UsageTrackerProps {
  admin: {
    remainingClicks: number;
    hasSubscription: boolean;
    subscriptionExpiresAt: string | null;
  };
  onUsageUpdate: () => void;
}

export function UsageTracker({ admin, onUsageUpdate }: UsageTrackerProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);

  const clickMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/usage/click");
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      onUsageUpdate();
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Usage Error",
        description: error.message || "Failed to track usage",
      });
    }
  });

  // Track iframe interactions with multiple detection methods
  useEffect(() => {
    let clickCount = 0;
    let lastClickTime = 0;
    
    const handleIframeInteraction = () => {
      const now = Date.now();
      // Prevent multiple rapid clicks (debounce)
      if (now - lastClickTime < 1000) return;
      
      if (!admin.hasSubscription && admin.remainingClicks > 0 && clickCount < 10) {
        lastClickTime = now;
        clickCount++;
        clickMutation.mutate();
      }
    };

    const iframe = document.getElementById('gis-frame') as HTMLIFrameElement;
    if (!iframe) return;

    // Method 1: Detect when iframe container is clicked
    const iframeContainer = iframe.parentElement;
    if (iframeContainer) {
      iframeContainer.addEventListener('click', handleIframeInteraction);
    }

    // Method 2: Detect when window loses focus while mouse is over iframe
    let mouseOverIframe = false;
    
    const handleMouseEnter = (e: Event) => {
      if (e.target === iframe || (e.target as Element)?.closest('#gis-frame')) {
        mouseOverIframe = true;
      }
    };
    
    const handleMouseLeave = (e: Event) => {
      if (!iframe.contains(e.relatedTarget as Node)) {
        mouseOverIframe = false;
      }
    };
    
    const handleWindowBlur = () => {
      if (mouseOverIframe) {
        handleIframeInteraction();
      }
    };
    
    const handleVisibilityChange = () => {
      if (document.hidden && mouseOverIframe) {
        handleIframeInteraction();
      }
    };

    // Add event listeners
    iframe.addEventListener('mouseenter', handleMouseEnter);
    iframe.addEventListener('mouseleave', handleMouseLeave);
    window.addEventListener('blur', handleWindowBlur);
    document.addEventListener('visibilitychange', handleVisibilityChange);
    
    // Method 3: Periodic check for iframe activity
    const activityCheck = setInterval(() => {
      if (mouseOverIframe && document.hasFocus() && !admin.hasSubscription && admin.remainingClicks > 0) {
        // Additional activity check could go here
      }
    }, 5000);

    return () => {
      if (iframeContainer) {
        iframeContainer.removeEventListener('click', handleIframeInteraction);
      }
      iframe.removeEventListener('mouseenter', handleMouseEnter);
      iframe.removeEventListener('mouseleave', handleMouseLeave);
      window.removeEventListener('blur', handleWindowBlur);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      clearInterval(activityCheck);
    };
  }, [admin.hasSubscription, admin.remainingClicks, clickMutation]);

  // Listen for test click events
  useEffect(() => {
    const handleTestClick = () => {
      if (!admin.hasSubscription && admin.remainingClicks > 0) {
        clickMutation.mutate();
      }
    };

    document.addEventListener('iframe-click', handleTestClick);
    return () => document.removeEventListener('iframe-click', handleTestClick);
  }, [admin.hasSubscription, admin.remainingClicks, clickMutation]);

  const isSubscriptionActive = admin.hasSubscription && admin.subscriptionExpiresAt && 
    new Date(admin.subscriptionExpiresAt) > new Date();

  const shouldShowSubscription = !isSubscriptionActive && admin.remainingClicks <= 3;

  const getProgressColor = () => {
    if (admin.remainingClicks <= 2) return "bg-red-500";
    if (admin.remainingClicks <= 5) return "bg-amber-500";
    return "bg-khisba-green";
  };

  const formatExpiryDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-GB');
  };

  return (
    <>
      <div className="bg-khisba-gray/80 backdrop-blur-sm border border-khisba-green/30 rounded-lg px-4 py-2 min-w-[200px] shadow-lg">
        <div className="space-y-2">
          {isSubscriptionActive ? (
            <div className="flex items-center justify-between">
              <Badge className="bg-gradient-to-r from-green-500 to-emerald-600 text-white shadow-lg">
                <Crown className="w-4 h-4 mr-2" />
                Premium Active
              </Badge>
              <span className="text-xs text-gray-300 font-medium" data-testid="text-subscription-expiry">
                Valid until {formatExpiryDate(admin.subscriptionExpiresAt!)}
              </span>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-white">Usage Remaining</span>
                <Badge className="bg-gradient-to-r from-khisba-green to-green-500 text-black font-bold px-3 py-1">
                  <MousePointer className="w-4 h-4 mr-1" />
                  {admin.remainingClicks}/10
                </Badge>
              </div>
              
              <div className="space-y-2">
                <div className="relative h-3 bg-gray-800 rounded-full overflow-hidden">
                  <div 
                    className="absolute left-0 top-0 h-full bg-gradient-to-r from-khisba-green to-green-500 transition-all duration-500 ease-out shadow-lg"
                    style={{ width: `${(admin.remainingClicks / 10) * 100}%` }}
                  />
                  <div className="absolute inset-0 rounded-full shadow-inner" />
                </div>
                <div className="text-sm text-center font-medium" data-testid="text-clicks-remaining">
                  {admin.remainingClicks === 0 ? (
                    <span className="text-red-400">⚠️ No clicks remaining</span>
                  ) : admin.remainingClicks <= 3 ? (
                    <span className="text-orange-400">⚡ {admin.remainingClicks} clicks left</span>
                  ) : (
                    <span className="text-khisba-green">✓ {admin.remainingClicks} clicks available</span>
                  )}
                </div>
              </div>

              {shouldShowSubscription || admin.remainingClicks <= 3 ? (
                <Button
                  onClick={() => setShowSubscriptionModal(true)}
                  size="sm"
                  className="w-full bg-gradient-to-r from-khisba-green to-emerald-500 hover:from-khisba-bright hover:to-emerald-400 text-black font-bold shadow-lg transition-all duration-200 hover:scale-105"
                  data-testid="button-upgrade"
                >
                  <Crown className="w-4 h-4 mr-2" />
                  Upgrade to Premium - 1000 DZD
                </Button>
              ) : null}
            </>
          )}
        </div>
      </div>

      <SubscriptionModal
        open={showSubscriptionModal}
        onOpenChange={setShowSubscriptionModal}
        remainingClicks={admin.remainingClicks}
      />
    </>
  );
}