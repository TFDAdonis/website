import { useState, useRef } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { paymentSchema, type PaymentData } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import { Loader2, CreditCard, CheckCircle, Info, Copy, Upload, Zap, Camera } from "lucide-react";

interface SubscriptionModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  remainingClicks: number;
}

export function SubscriptionModal({ open, onOpenChange, remainingClicks }: SubscriptionModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [step, setStep] = useState<'info' | 'payment' | 'confirmation'>('info');
  const [paymentResult, setPaymentResult] = useState<any>(null);
  const [voucherImage, setVoucherImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const form = useForm<PaymentData>({
    resolver: zodResolver(paymentSchema),
    defaultValues: {
      amount: 1000,
      ccpAccountNumber: "",
      voucherCode: "",
      voucherImageUrl: ""
    }
  });

  // Demo subscription mutation
  const demoMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", "/api/demo/activate-subscription", {});
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Demo Subscription Activated! 🎉",
        description: "You now have 7 days of unlimited GIS access for testing.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      onOpenChange(false);
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Demo Activation Failed",
        description: error.message || "Failed to activate demo subscription",
      });
    }
  });

  const paymentMutation = useMutation({
    mutationFn: async (data: PaymentData) => {
      const dataWithImage = {
        ...data,
        voucherImageUrl: voucherImage || ""
      };
      const response = await apiRequest("POST", "/api/payment/create", dataWithImage);
      return response.json();
    },
    onSuccess: (data) => {
      setPaymentResult(data);
      setStep('confirmation');
      toast({
        title: "Payment Request Created",
        description: "Please complete the bank transfer to activate your subscription.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
    },
    onError: (error: any) => {
      toast({
        variant: "destructive",
        title: "Payment Error",
        description: error.message || "Failed to create payment request",
      });
    }
  });

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        setVoucherImage(result);
        toast({
          title: "Voucher Image Added",
          description: "Payment voucher image has been attached.",
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = (data: PaymentData) => {
    paymentMutation.mutate(data);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied to clipboard",
      description: "Account number copied successfully",
    });
  };

  const handleClose = () => {
    setStep('info');
    setPaymentResult(null);
    setVoucherImage(null);
    form.reset();
    onOpenChange(false);
  };

  const renderInfoStep = () => (
    <div className="space-y-6" data-testid="subscription-info">
      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          You have <Badge variant="destructive">{remainingClicks} clicks remaining</Badge>. Subscribe for unlimited access to GIS features.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Monthly Subscription
          </CardTitle>
          <CardDescription>
            Get unlimited access to all GIS features and tools
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-2xl font-bold text-primary">1000 DZD/month</div>
          <ul className="space-y-2 text-sm text-muted-foreground">
            <li className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              Unlimited GIS application usage
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              Full access to mapping tools
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              Premium support and updates
            </li>
          </ul>
          
          <div className="flex gap-3">
            <Button 
              onClick={() => setStep('payment')}
              className="flex-1"
              data-testid="button-subscribe"
            >
              Subscribe Now
            </Button>
            
            <Button 
              onClick={() => demoMutation.mutate()}
              variant="outline"
              disabled={demoMutation.isPending}
              className="flex-1"
              data-testid="button-demo"
            >
              {demoMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Activating...
                </>
              ) : (
                <>
                  <Zap className="mr-2 h-4 w-4" />
                  Try Demo (7 Days)
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );

  const renderPaymentStep = () => (
    <div className="space-y-6" data-testid="payment-form">
      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription>
          Transfer 1000 DZD to CCP account <strong>0028228244</strong> with your voucher code.
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle>Payment Information</CardTitle>
          <CardDescription>
            Complete the form below and make the bank transfer
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <Label htmlFor="ccpAccount">Your CCP Account Number</Label>
              <Input
                id="ccpAccount"
                {...form.register("ccpAccountNumber")}
                placeholder="Enter your CCP account number"
                data-testid="input-ccp-account"
              />
              {form.formState.errors.ccpAccountNumber && (
                <p className="text-sm text-destructive mt-1">
                  {form.formState.errors.ccpAccountNumber.message}
                </p>
              )}
            </div>

            <div>
              <Label htmlFor="voucherCode">Voucher Code</Label>
              <Input
                id="voucherCode"
                {...form.register("voucherCode")}
                placeholder="Enter voucher/reference code from transfer"
                data-testid="input-voucher-code"
              />
              {form.formState.errors.voucherCode && (
                <p className="text-sm text-destructive mt-1">
                  {form.formState.errors.voucherCode.message}
                </p>
              )}
            </div>

            <div className="space-y-2">
              <Label>Payment Voucher Image (Optional)</Label>
              <div className="border-2 border-dashed border-muted-foreground/25 rounded-lg p-4">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImageUpload}
                  accept="image/*"
                  className="hidden"
                  data-testid="input-voucher-image"
                />
                
                {voucherImage ? (
                  <div className="space-y-3">
                    <img
                      src={voucherImage}
                      alt="Payment voucher"
                      className="max-w-full h-32 object-cover rounded-lg mx-auto"
                    />
                    <div className="flex gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => fileInputRef.current?.click()}
                        className="flex-1"
                        data-testid="button-change-image"
                      >
                        <Camera className="mr-2 h-4 w-4" />
                        Change Image
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setVoucherImage(null)}
                        className="flex-1"
                        data-testid="button-remove-image"
                      >
                        Remove
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => fileInputRef.current?.click()}
                      data-testid="button-upload-image"
                    >
                      <Upload className="mr-2 h-4 w-4" />
                      Upload Payment Voucher
                    </Button>
                    <p className="text-sm text-muted-foreground mt-2">
                      Upload a photo of your payment receipt or voucher for faster verification
                    </p>
                  </div>
                )}
              </div>
            </div>

            <div className="bg-muted p-4 rounded-lg">
              <h4 className="font-semibold mb-2">Transfer Details:</h4>
              <div className="space-y-1 text-sm">
                <div className="flex justify-between items-center">
                  <span>Account Number:</span>
                  <span className="font-mono flex items-center gap-2">
                    0028228244
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => copyToClipboard("0028228244")}
                      data-testid="button-copy-account"
                    >
                      <Copy className="h-3 w-3" />
                    </Button>
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Amount:</span>
                  <span className="font-semibold">1000 DZD</span>
                </div>
              </div>
            </div>

            <div className="flex gap-3">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => setStep('info')}
                className="flex-1"
                data-testid="button-back"
              >
                Back
              </Button>
              <Button 
                type="submit" 
                disabled={paymentMutation.isPending}
                className="flex-1"
                data-testid="button-submit-payment"
              >
                {paymentMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Processing...
                  </>
                ) : (
                  'Submit Payment Request'
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );

  const renderConfirmationStep = () => (
    <div className="space-y-6" data-testid="payment-confirmation">
      <Alert>
        <CheckCircle className="h-4 w-4" />
        <AlertDescription>
          Your payment request has been submitted successfully!
        </AlertDescription>
      </Alert>

      <Card>
        <CardHeader>
          <CardTitle>Payment Request Details</CardTitle>
          <CardDescription>
            Your subscription will be activated once payment is verified
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {paymentResult && (
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span>Payment ID:</span>
                <span className="font-mono">{paymentResult.payment?.id}</span>
              </div>
              <div className="flex justify-between">
                <span>Amount:</span>
                <span className="font-semibold">{paymentResult.payment?.amount} DZD</span>
              </div>
              <div className="flex justify-between">
                <span>Status:</span>
                <Badge variant="secondary">{paymentResult.payment?.status}</Badge>
              </div>
            </div>
          )}
          
          <Alert>
            <Info className="h-4 w-4" />
            <AlertDescription>
              {paymentResult?.message || "Please complete the bank transfer to activate your subscription."}
            </AlertDescription>
          </Alert>

          <Button 
            onClick={handleClose} 
            className="w-full"
            data-testid="button-close"
          >
            Close
          </Button>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            GIS Subscription
          </DialogTitle>
          <DialogDescription>
            {step === 'info' && 'Choose your subscription plan'}
            {step === 'payment' && 'Complete your payment information'}
            {step === 'confirmation' && 'Payment request submitted'}
          </DialogDescription>
        </DialogHeader>

        {step === 'info' && renderInfoStep()}
        {step === 'payment' && renderPaymentStep()}
        {step === 'confirmation' && renderConfirmationStep()}
      </DialogContent>
    </Dialog>
  );
}