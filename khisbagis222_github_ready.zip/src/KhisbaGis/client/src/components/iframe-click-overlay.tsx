import { useEffect, useRef } from "react";

interface IframeClickOverlayProps {
  onIframeClick: () => void;
  enabled: boolean;
}

export function IframeClickOverlay({ onIframeClick, enabled }: IframeClickOverlayProps) {
  const overlayRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!enabled) return;

    const handleMouseEvents = () => {
      let isMouseOverIframe = false;
      let hasClicked = false;

      const handleMouseEnter = () => {
        isMouseOverIframe = true;
        hasClicked = false;
      };

      const handleMouseLeave = () => {
        if (isMouseOverIframe && !hasClicked) {
          // User likely clicked on iframe
          onIframeClick();
          hasClicked = true;
        }
        isMouseOverIframe = false;
      };

      const handleClick = () => {
        if (isMouseOverIframe) {
          onIframeClick();
          hasClicked = true;
        }
      };

      const iframe = document.getElementById('gis-frame');
      if (iframe && overlayRef.current) {
        overlayRef.current.addEventListener('mouseenter', handleMouseEnter);
        overlayRef.current.addEventListener('mouseleave', handleMouseLeave);
        overlayRef.current.addEventListener('click', handleClick);

        return () => {
          overlayRef.current?.removeEventListener('mouseenter', handleMouseEnter);
          overlayRef.current?.removeEventListener('mouseleave', handleMouseLeave);
          overlayRef.current?.removeEventListener('click', handleClick);
        };
      }
    };

    return handleMouseEvents();
  }, [onIframeClick, enabled]);

  if (!enabled) return null;

  return (
    <div
      ref={overlayRef}
      className="absolute inset-0 z-10 pointer-events-auto"
      style={{ 
        background: 'transparent',
        cursor: 'pointer'
      }}
      title="Click to interact with GIS"
    />
  );
}