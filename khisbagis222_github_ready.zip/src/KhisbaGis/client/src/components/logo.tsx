interface LogoProps {
  size?: "sm" | "md" | "lg";
  showText?: boolean;
  className?: string;
}

export function Logo({ size = "md", showText = true, className = "" }: LogoProps) {
  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-12 h-12", 
    lg: "w-20 h-20"
  };

  const textSizeClasses = {
    sm: "text-lg",
    md: "text-2xl",
    lg: "text-4xl"
  };

  return (
    <div className={`flex items-center space-x-3 ${className}`}>
      {/* Globe with Grid Pattern */}
      <div className={`${sizeClasses[size]} relative`}>
        <svg viewBox="0 0 120 120" className="w-full h-full">
          {/* Globe Background */}
          <circle 
            cx="60" 
            cy="60" 
            r="58" 
            fill="#000" 
            stroke="url(#greenGradient)" 
            strokeWidth="2"
          />
          
          {/* Grid Pattern */}
          <g stroke="#00D470" strokeWidth="0.8" fill="none" opacity="0.7">
            {/* Longitude lines */}
            <path d="M 20 60 Q 60 20 100 60 Q 60 100 20 60" />
            <path d="M 30 60 Q 60 30 90 60 Q 60 90 30 60" />
            <path d="M 40 60 Q 60 40 80 60 Q 60 80 40 60" />
            <path d="M 100 60 Q 60 20 20 60 Q 60 100 100 60" />
            <path d="M 90 60 Q 60 30 30 60 Q 60 90 90 60" />
            <path d="M 80 60 Q 60 40 40 60 Q 60 80 80 60" />
            
            {/* Latitude lines */}
            <ellipse cx="60" cy="60" rx="55" ry="20" />
            <ellipse cx="60" cy="60" rx="55" ry="35" />
            <ellipse cx="60" cy="60" rx="55" ry="50" />
            <line x1="5" y1="60" x2="115" y2="60" />
          </g>
          
          {/* Center highlight */}
          <circle cx="60" cy="60" r="4" fill="#00FF88" />
          
          {/* Sparkle */}
          <g fill="#00FF88">
            <polygon points="25,25 27,30 32,28 27,33 25,38 23,33 18,28 23,30" opacity="0.8" />
            <polygon points="95,35 96,38 99,37 96,40 95,43 94,40 91,37 94,38" opacity="0.6" />
          </g>
          
          <defs>
            <linearGradient id="greenGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#00FF88" />
              <stop offset="100%" stopColor="#00D470" />
            </linearGradient>
          </defs>
        </svg>
      </div>
      
      {showText && (
        <div>
          <h1 className={`font-bold text-khisba-bright tracking-wider ${textSizeClasses[size]}`}>
            KHISBA GIS
          </h1>
          {size === "lg" && (
            <p className="text-gray-400 text-sm mt-1">
              Professional Geographic Information Systems
            </p>
          )}
        </div>
      )}
    </div>
  );
}
