import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import { storage } from "./storage";
import { loginSchema, paymentSchema } from "@shared/schema";
import { ZodError } from "zod";

declare module "express-session" {
  interface SessionData {
    adminId?: string;
    sessionId?: string;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Session middleware
  app.use(session({
    secret: process.env.SESSION_SECRET || "khisba-gis-secret-key",
    resave: false,
    saveUninitialized: false,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      httpOnly: true,
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));

  // Login endpoint
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const loginData = loginSchema.parse(req.body);
      
      const admin = await storage.getAdminByUsername(loginData.username);
      if (!admin) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const isValidPassword = await storage.validatePassword(loginData.password, admin.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      const session = await storage.createSession(admin.id);
      req.session.adminId = admin.id;
      req.session.sessionId = session.id;

      res.json({ 
        message: "Login successful", 
        admin: { id: admin.id, username: admin.username } 
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Logout endpoint
  app.post("/api/auth/logout", async (req: Request, res: Response) => {
    try {
      if (req.session.sessionId) {
        await storage.deleteSession(req.session.sessionId);
      }
      req.session.destroy((err) => {
        if (err) {
          return res.status(500).json({ message: "Could not log out" });
        }
        res.json({ message: "Logout successful" });
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Check authentication status
  app.get("/api/auth/me", async (req: Request, res: Response) => {
    try {
      if (!req.session.adminId || !req.session.sessionId) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const session = await storage.getSession(req.session.sessionId);
      if (!session) {
        req.session.destroy(() => {});
        return res.status(401).json({ message: "Session expired" });
      }

      const admin = await storage.getAdmin(req.session.adminId);
      if (!admin) {
        return res.status(401).json({ message: "Admin not found" });
      }

      res.json({ 
        admin: { 
          id: admin.id, 
          username: admin.username,
          remainingClicks: admin.remainingClicks,
          hasSubscription: admin.hasSubscription,
          subscriptionExpiresAt: admin.subscriptionExpiresAt
        },
        session: { id: session.id, expiresAt: session.expiresAt }
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Decrement clicks when GIS is used
  app.post("/api/usage/click", async (req: Request, res: Response) => {
    try {
      if (!req.session.adminId) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const admin = await storage.decrementClicks(req.session.adminId);
      if (!admin) {
        return res.status(404).json({ message: "Admin not found" });
      }

      res.json({
        remainingClicks: admin.remainingClicks,
        hasSubscription: admin.hasSubscription,
        subscriptionExpiresAt: admin.subscriptionExpiresAt
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Create payment
  app.post("/api/payment/create", async (req: Request, res: Response) => {
    try {
      if (!req.session.adminId) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const paymentData = paymentSchema.parse(req.body);
      const payment = await storage.createPayment(req.session.adminId, paymentData);
      
      res.json({ 
        payment: {
          id: payment.id,
          amount: payment.amount,
          ccpAccountNumber: payment.ccpAccountNumber,
          voucherCode: payment.voucherCode,
          status: payment.status,
          createdAt: payment.createdAt
        },
        message: "Payment request created. Please transfer the amount to CCP account 0028228244 with your voucher code."
      });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Invalid input", errors: error.errors });
      }
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Get payments for admin
  app.get("/api/payment/history", async (req: Request, res: Response) => {
    try {
      if (!req.session.adminId) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const payments = await storage.getAdminPayments(req.session.adminId);
      res.json({ payments });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Admin endpoint to confirm payment (simulate bank verification)
  app.post("/api/payment/confirm/:paymentId", async (req: Request, res: Response) => {
    try {
      const { paymentId } = req.params;
      const payment = await storage.confirmPayment(paymentId);
      
      if (!payment) {
        return res.status(404).json({ message: "Payment not found or already processed" });
      }

      res.json({ 
        message: "Payment confirmed successfully. Subscription activated.",
        payment
      });
    } catch (error) {
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Demo route - activate subscription for testing
  app.post("/api/demo/activate-subscription", async (req: Request, res: Response) => {
    try {
      if (!req.session.adminId) {
        return res.status(401).json({ message: "Not authenticated" });
      }

      const updatedAdmin = await storage.activateDemoSubscription(req.session.adminId);
      if (!updatedAdmin) {
        return res.status(404).json({ message: "Admin not found" });
      }
      
      res.json({ 
        message: "Demo subscription activated for 7 days",
        admin: {
          id: updatedAdmin.id,
          username: updatedAdmin.username,
          remainingClicks: updatedAdmin.remainingClicks,
          hasSubscription: updatedAdmin.hasSubscription,
          subscriptionExpiresAt: updatedAdmin.subscriptionExpiresAt
        }
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to activate demo subscription" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
