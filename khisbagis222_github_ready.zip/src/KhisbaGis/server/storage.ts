import { type Admin, type InsertAdmin, type Session, type Payment, type PaymentData } from "@shared/schema";
import { randomUUID } from "crypto";
import bcrypt from "bcrypt";

export interface IStorage {
  getAdmin(id: string): Promise<Admin | undefined>;
  getAdminByUsername(username: string): Promise<Admin | undefined>;
  createAdmin(admin: InsertAdmin): Promise<Admin>;
  updateAdmin(id: string, updates: Partial<Admin>): Promise<Admin | undefined>;
  validatePassword(password: string, hashedPassword: string): Promise<boolean>;
  createSession(adminId: string): Promise<Session>;
  getSession(sessionId: string): Promise<Session | undefined>;
  deleteSession(sessionId: string): Promise<void>;
  isSessionValid(session: Session): boolean;
  decrementClicks(adminId: string): Promise<Admin | undefined>;
  createPayment(adminId: string, paymentData: PaymentData): Promise<Payment>;
  getPayment(id: string): Promise<Payment | undefined>;
  confirmPayment(id: string): Promise<Payment | undefined>;
  getAdminPayments(adminId: string): Promise<Payment[]>;
}

export class MemStorage implements IStorage {
  private admins: Map<string, Admin>;
  private sessions: Map<string, Session>;
  private payments: Map<string, Payment>;

  constructor() {
    this.admins = new Map();
    this.sessions = new Map();
    this.payments = new Map();
    
    // Initialize with default admin user
    this.initializeDefaultAdmin();
  }

  private async initializeDefaultAdmin() {
    const hashedPassword = await bcrypt.hash("gis2024", 10);
    const defaultAdmin: Admin = {
      id: randomUUID(),
      username: "admin",
      password: hashedPassword,
      remainingClicks: 10,
      hasSubscription: false,
      subscriptionExpiresAt: null,
      createdAt: new Date(),
    };
    this.admins.set(defaultAdmin.id, defaultAdmin);
  }

  async getAdmin(id: string): Promise<Admin | undefined> {
    return this.admins.get(id);
  }

  async getAdminByUsername(username: string): Promise<Admin | undefined> {
    return Array.from(this.admins.values()).find(
      (admin) => admin.username === username,
    );
  }

  async createAdmin(insertAdmin: InsertAdmin): Promise<Admin> {
    const id = randomUUID();
    const hashedPassword = await bcrypt.hash(insertAdmin.password, 10);
    const admin: Admin = { 
      ...insertAdmin, 
      id, 
      password: hashedPassword,
      remainingClicks: 10,
      hasSubscription: false,
      subscriptionExpiresAt: null,
      createdAt: new Date(),
    };
    this.admins.set(id, admin);
    return admin;
  }

  async updateAdmin(id: string, updates: Partial<Admin>): Promise<Admin | undefined> {
    const admin = this.admins.get(id);
    if (!admin) return undefined;
    
    const updatedAdmin = { ...admin, ...updates };
    this.admins.set(id, updatedAdmin);
    return updatedAdmin;
  }

  async validatePassword(password: string, hashedPassword: string): Promise<boolean> {
    return bcrypt.compare(password, hashedPassword);
  }

  async createSession(adminId: string): Promise<Session> {
    const sessionId = randomUUID();
    const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours
    const session: Session = {
      id: sessionId,
      adminId,
      createdAt: new Date(),
      expiresAt,
    };
    this.sessions.set(sessionId, session);
    return session;
  }

  async getSession(sessionId: string): Promise<Session | undefined> {
    const session = this.sessions.get(sessionId);
    if (session && this.isSessionValid(session)) {
      return session;
    }
    if (session) {
      this.sessions.delete(sessionId);
    }
    return undefined;
  }

  async deleteSession(sessionId: string): Promise<void> {
    this.sessions.delete(sessionId);
  }

  isSessionValid(session: Session): boolean {
    return new Date() < session.expiresAt;
  }

  async decrementClicks(adminId: string): Promise<Admin | undefined> {
    const admin = this.admins.get(adminId);
    if (!admin) return undefined;
    
    if (admin.hasSubscription && admin.subscriptionExpiresAt && admin.subscriptionExpiresAt > new Date()) {
      return admin; // Unlimited clicks for active subscribers
    }
    
    if (admin.remainingClicks <= 0) return admin;
    
    const updatedAdmin = { ...admin, remainingClicks: admin.remainingClicks - 1 };
    this.admins.set(adminId, updatedAdmin);
    return updatedAdmin;
  }

  async createPayment(adminId: string, paymentData: PaymentData): Promise<Payment> {
    const id = randomUUID();
    const payment: Payment = {
      id,
      adminId,
      amount: paymentData.amount,
      ccpAccountNumber: paymentData.ccpAccountNumber,
      voucherCode: paymentData.voucherCode,
      voucherImageUrl: paymentData.voucherImageUrl || null,
      status: "pending",
      createdAt: new Date(),
      confirmedAt: null,
    };
    this.payments.set(id, payment);
    return payment;
  }

  async getPayment(id: string): Promise<Payment | undefined> {
    return this.payments.get(id);
  }

  async confirmPayment(id: string): Promise<Payment | undefined> {
    const payment = this.payments.get(id);
    if (!payment || payment.status !== "pending") return undefined;
    
    const confirmedPayment = {
      ...payment,
      status: "confirmed" as const,
      confirmedAt: new Date(),
    };
    this.payments.set(id, confirmedPayment);
    
    // Update admin subscription
    const admin = this.admins.get(payment.adminId);
    if (admin) {
      const subscriptionExpiresAt = new Date();
      subscriptionExpiresAt.setMonth(subscriptionExpiresAt.getMonth() + 1); // 1 month subscription
      
      const updatedAdmin = {
        ...admin,
        hasSubscription: true,
        subscriptionExpiresAt,
        remainingClicks: 10, // Reset clicks
      };
      this.admins.set(payment.adminId, updatedAdmin);
    }
    
    return confirmedPayment;
  }

  async getAdminPayments(adminId: string): Promise<Payment[]> {
    return Array.from(this.payments.values()).filter(payment => payment.adminId === adminId);
  }

  // Demo function - activate subscription immediately for testing
  async activateDemoSubscription(adminId: string): Promise<Admin | undefined> {
    const admin = this.admins.get(adminId);
    if (!admin) return undefined;
    
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 7); // 7 days demo subscription
    
    const updatedAdmin = {
      ...admin,
      hasSubscription: true,
      subscriptionExpiresAt: expiresAt,
      remainingClicks: 10, // Reset clicks
    };
    
    this.admins.set(adminId, updatedAdmin);
    return updatedAdmin;
  }
}

export const storage = new MemStorage();
