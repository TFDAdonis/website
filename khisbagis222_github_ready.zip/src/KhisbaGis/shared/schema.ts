import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const admins = pgTable("admins", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  remainingClicks: integer("remaining_clicks").default(10).notNull(),
  hasSubscription: boolean("has_subscription").default(false).notNull(),
  subscriptionExpiresAt: timestamp("subscription_expires_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const sessions = pgTable("sessions", {
  id: varchar("id").primaryKey(),
  adminId: varchar("admin_id").notNull().references(() => admins.id),
  createdAt: timestamp("created_at").defaultNow(),
  expiresAt: timestamp("expires_at").notNull(),
});

export const payments = pgTable("payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  adminId: varchar("admin_id").notNull().references(() => admins.id),
  amount: integer("amount").notNull(), // Amount in DZD
  ccpAccountNumber: text("ccp_account_number").notNull(),
  voucherCode: text("voucher_code").notNull(),
  voucherImageUrl: text("voucher_image_url"), // Image proof of payment
  status: text("status").default("pending").notNull(), // pending, confirmed, rejected
  createdAt: timestamp("created_at").defaultNow(),
  confirmedAt: timestamp("confirmed_at"),
});

export const insertAdminSchema = createInsertSchema(admins).pick({
  username: true,
  password: true,
});

export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export const paymentSchema = z.object({
  amount: z.number().min(1000, "Minimum payment is 1000 DZD"),
  ccpAccountNumber: z.string().min(1, "CCP account number is required"),
  voucherCode: z.string().min(1, "Voucher code is required"),
  voucherImageUrl: z.string().optional(),
});

export type InsertAdmin = z.infer<typeof insertAdminSchema>;
export type Admin = typeof admins.$inferSelect;
export type Session = typeof sessions.$inferSelect;
export type Payment = typeof payments.$inferSelect;
export type LoginData = z.infer<typeof loginSchema>;
export type PaymentData = z.infer<typeof paymentSchema>;
