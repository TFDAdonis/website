# replit.md

## Overview

This is a GIS (Geographic Information System) web application called "Khisba GIS" built with a modern full-stack architecture. The application features a React frontend with TypeScript and a Node.js/Express backend, designed for administrative access to geographic data and mapping functionality. The app includes user authentication, a freemium usage model (10 free clicks, then 1000 DZD monthly subscription), and displays GIS content through a Google Earth Engine iframe. Payment processing is integrated with CCP bank account 0028228244.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite for fast development and building
- **UI Library**: Shadcn/ui components built on Radix UI primitives for accessible, customizable components
- **Styling**: Tailwind CSS with CSS variables for theming and responsive design
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and API calls
- **Form Handling**: React Hook Form with Zod validation for type-safe forms

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **Session Management**: Express sessions with configurable storage (currently in-memory, designed for PostgreSQL with connect-pg-simple)
- **Authentication**: Custom session-based auth with bcrypt for password hashing
- **API Design**: RESTful endpoints with JSON responses and centralized error handling

### Data Storage
- **Database**: PostgreSQL configured through Neon Database serverless connection
- **ORM**: Drizzle ORM for type-safe database operations and migrations
- **Schema**: Defined in shared TypeScript files for consistency between frontend and backend
- **Session Storage**: Designed to use PostgreSQL with connect-pg-simple for production sessions

### Authentication & Authorization
- **Strategy**: Session-based authentication using Express sessions
- **Password Security**: bcrypt hashing with salt rounds for secure password storage
- **Session Management**: HTTP-only cookies with configurable security settings
- **Default Credentials**: Ships with default admin user (username: "admin", password: "gis2024")
- **Usage Model**: Freemium with 10 free clicks per user, then paid subscription required

### Payment & Subscription System
- **Pricing**: 1000 DZD per month for unlimited GIS access
- **Payment Method**: CCP bank transfer to account 0028228244
- **Verification**: Manual payment confirmation using voucher codes
- **Features**: Click tracking, subscription management, payment history

### Development & Build System
- **Build Tool**: Vite for frontend bundling with React plugin
- **Backend Build**: ESBuild for server-side TypeScript compilation
- **Development**: Hot module replacement and error overlay for smooth development experience
- **Type Safety**: Shared TypeScript schemas between frontend and backend using Zod

## External Dependencies

### Database Services
- **Neon Database**: Serverless PostgreSQL database hosting
- **Connection**: Uses @neondatabase/serverless for database connectivity

### UI & Styling
- **Radix UI**: Comprehensive set of unstyled, accessible UI primitives
- **Tailwind CSS**: Utility-first CSS framework for styling
- **Lucide React**: Icon library for consistent iconography
- **Google Fonts**: External font loading (Architects Daughter, DM Sans, Fira Code, Geist Mono)

### Development Tools
- **Replit Integration**: Custom Replit plugins for development environment integration
- **PostCSS**: CSS processing with Autoprefixer for vendor prefixes

### Form & Validation
- **Zod**: Runtime type validation and schema definition
- **React Hook Form**: Performance-focused form library with minimal re-renders

### Session & Security
- **bcrypt**: Password hashing library for secure authentication
- **express-session**: Session middleware for Express with PostgreSQL storage support